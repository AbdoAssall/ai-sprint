import "dotenv/config";
import express from "express";
import passport from "passport";
import authRoutes from "./modules/auth/auth.routes.js";
import protectedRoutes from './routes/protected.routes.js';
import verfiyToken from "./utils/verfiyToken.js";
import "./config/passport.js";

const app = express();

app.use(express.json());
app.use(passport.initialize());

app.use("/api/v1/auth", authRoutes);
app.use("/api/v1", verfiyToken, protectedRoutes);

export default app;
